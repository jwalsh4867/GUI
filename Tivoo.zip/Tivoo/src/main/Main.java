package main;

import gui.TivooViewer;
import input.*;
import processor.*;
import output.*;

import java.io.IOException;
import java.util.*;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom.JDOMException;
import org.w3c.dom.DOMException;



public class Main {

    CalParser a;
    private static TivooViewer foo;
    
    public static void main(String[] args) throws JDOMException, IOException{
    	foo = new TivooViewer();
    	foo.launchGUI();
    }
}